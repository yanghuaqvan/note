package com.zhisheng.state.queryablestate;

/**
 * Desc: QueryClient
 * Created by zhisheng on 2019-07-05
 * blog：http://www.54tianzhisheng.cn/
 * 微信公众号：zhisheng
 */
public class QueryClient {
    public static void main(String[] args) {

    }
}
