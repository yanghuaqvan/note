package com.zhisheng.state;

/**
 * Desc:
 * Created by zhisheng on 2019-04-18
 * blog：http://www.54tianzhisheng.cn/
 * 微信公众号：zhisheng
 */
public class Main {
    public static void main(String[] args) {




        //file:///netdata/addon/flink/data/state/log
    }
}
