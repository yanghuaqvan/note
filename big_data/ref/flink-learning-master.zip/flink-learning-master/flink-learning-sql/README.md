### Flink-learning-sql

Flink Table API & SQL 

+ [flink sql ago](./flink-learning-sql-ago)
+ [flink sql blink](./flink-learning-sql-blink)

https://github.com/ververica/sql-training