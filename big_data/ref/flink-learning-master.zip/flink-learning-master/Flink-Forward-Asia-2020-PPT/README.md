
Flink Forward Asia 2020 在北京召开的，有主会场和几个分会场（企业实践、Apache Flink 核心技术、开源大数据生态、实时数仓、人工智能），内容涉及很多，可以查看下面图片介绍。

![](http://zhisheng-blog.oss-cn-hangzhou.aliyuncs.com/2020-12-21-142353.png)

![](http://zhisheng-blog.oss-cn-hangzhou.aliyuncs.com/2020-12-21-142431.png)

![](http://zhisheng-blog.oss-cn-hangzhou.aliyuncs.com/2020-12-21-142511.png)

![](http://zhisheng-blog.oss-cn-hangzhou.aliyuncs.com/2020-12-21-142538.png)

![](http://zhisheng-blog.oss-cn-hangzhou.aliyuncs.com/2020-12-21-142616.png)

![](http://zhisheng-blog.oss-cn-hangzhou.aliyuncs.com/2020-12-21-142643.png)


### 如何获取上面这些 PPT？

上面的这些 PPT 本人已经整理好了，你可以扫描下面二维码，关注微信公众号：zhisheng，然后在里面回复关键字: **ffa2020** 即可获取已放出的 PPT。

![](http://zhisheng-blog.oss-cn-hangzhou.aliyuncs.com/2019-12-28-144329.jpg)