
Flink Forward 2020 是在线上举办的一次会议

1、《Keynote:Introducing Stateful Functions 2.0: Stream Processing meets Serverless Applications》
Stephan Ewen – Apache Flink PMC,Ververica Co-founder, CTO

讲解嘉宾：李钰（绝顶） – Apache Flink Committer，Apache Flink 1.10 Release Manager，阿里巴巴高级技术专家

2、《Keynote:Stream analytics made real with Pravega and Apache Flink》
  Srikanth Satya – VP of Engineering at DellEMC
  
讲解嘉宾：滕昱 – DellEMC 技术总监

3、《Keynote:Apache Flink – Completing Cloudera’s End to End Streaming Platform》
  Marton Balassi – Apache Flink PMC ，Senior Solutions Architect at Cloudera
  
Joe Witt – VP of Engineering at Cloudera

讲解嘉宾：杨克特（鲁尼） – Apache Member, Apache Flink PMC, 阿里巴巴高级技术专家

4、《Keynote:The Evolution of Data Infrastructure at Splunk》
Eric Sammer – Distinguished Engineer at Splunk

讲解嘉宾：王治江（淘江） – 阿里巴巴高级技术专家

5、《Flink SQL 之 2020：舍我其谁》
Fabian Hueske, & Timo Walther

讲解嘉宾：伍翀（云邪），Apache Flink PMC，阿里巴巴技术专家

6、《微博基于 Flink 的机器学习实践》

分享嘉宾：

于茜，微博机器学习研发中心高级算法工程师。多年来致力于使用 Flink 构建实时数据处理和在线机器学习框架，有丰富的社交媒体应用推荐系统的开发经验。

曹富强，微博机器学习研发中心系统工程师。现负责微博机器学习平台数据计算模块。主要涉及实时计算 Flink，Storm，Spark Streaming，离线计算 Hive，Spark 等。目前专注于 Flink 在微博机器学习场景的应用。

于翔，微博机器学习研发中心算法架构工程师。

7、《Flink’s application at Didi》
 
分享嘉宾：薛康 – 现任滴滴技术专家，实时计算负责人

8、《Alink：提升基于 Flink 的机器学习平台易用性》

分享嘉宾：杨旭（品数） – 阿里巴巴资深技术专家。

9、《Google: 机器学习工作流的分布式处理》
Ahmet Altay & Reza Rokni & Robert Crowe

讲解嘉宾：秦江杰 – Apache Flink PMC，阿里巴巴高级技术专家

10、《Flink + AI Flow：让 AI 易如反掌》

分享嘉宾：秦江杰 – Apache Flink PMC，阿里巴巴高级技术专家

11、《终于等到你：PyFlink + Zeppelin》

分享嘉宾：

孙金城（金竹） – Apache Member，Apache Flink PMC，阿里巴巴高级技术专家

章剑锋（简锋） – Apache Member，Apache Zeppelin PMC，阿里巴巴高级技术专家

12、《Uber ：使用 Flink CEP 进行地理情形检测的实践》
Teng (Niel) Hu

讲解嘉宾：付典 – Apache Flink Committer，阿里巴巴技术专家

13、《AWS: 如何在全托管 Apache Flink 服务中提供应用高可用》

Ryan Nienhuis & Tirtha Chatterjee
   
讲解嘉宾：章剑锋（简锋） – Apache Member，Apache Zeppelin PMC，阿里巴巴高级技术专家

14、《Production-Ready Flink and Hive Integration – what story you can tell now?》

Bowen Li
   
讲解嘉宾：李锐（天离） – Apache Hive PMC，阿里巴巴技术专家


15、《Data Warehouse, Data Lakes, What’s Next?》
Xiaowei Jiang

讲解嘉宾：金晓军（仙隐） – 阿里巴巴高级技术专家

16、《Netflix 的 Flink 自动扩缩容》

Abhay Amin
   
讲解嘉宾：吕文龙（龙三），阿里巴巴技术专家

17、《Apache Flink 误用之痛》

Konstantin Knauf

讲解嘉宾：孙金城（金竹） – Apache Member，Apache Flink PMC，阿里巴巴高级技术专家
   
18、《A deep dive into Flink SQL》

分享嘉宾：伍翀（云邪），Apache Flink PMC，阿里巴巴技术专家

19、《Lyft: 基于Flink的准实时海量数据分析平台》

Ying Xu & Kailash Hassan Dayanand

讲解嘉宾：王阳（亦祺），阿里巴巴技术专家


### 如何获取上面这些 PPT？

上面的这些 PPT 本人已经整理好了，你可以扫描下面二维码，关注微信公众号：zhisheng，然后在里面回复关键字: **ff2020** 即可获取已放出的 PPT。

![](http://zhisheng-blog.oss-cn-hangzhou.aliyuncs.com/2019-12-28-144329.jpg)