### Flink-learning-example

该 module 存放一些简单的测试用例。

#### batch

+ accumulator
+ wordcount


#### Streaming

+ async
+ broadcast
+ checkpoint
+ exception
+ file
+ iteration
+ join
+ machine-learning
+ remote
+ sideoutput
+ socket
+ watermark
+ wordcount
