## Flink 项目

+ [基于 Apache Flink 的日志实时处理系统](./flink-learning-project-log)

+ [基于 Apache Flink 的百亿数据去重实践](./flink-learning-project-deduplication)

+ [基于 Apache Flink 的监控告警系统](./flink-learning-project-monitor-alert)

+ [基于 Apache Flink 的实时风控系统](./flink-learning-project-risk-management)

+ [基于 Apache Flink 的实时大屏系统](./flink-learning-project-monitor-dashboard)

+ [Apache Flink 实时作业脚手架](./flink-learning-project-flink-job-scaffold)

+ [基于 Apache Flink 的实时数仓建设](./flink-learning-project-real-time-data-warehouse)

+ [基于 Apache Flink 的实时计算平台建设](./flink-learning-project-real-time-computing-platform)
