package com.zhisheng.alert.utils;


/**
 * 钉钉工作通知工具类
 * https://open-doc.dingtalk.com/microapp/serverapi2/pgoxpy
 */
public class DingDingWorkspaceNoticeUtil {
    public static final String workNotifyUrl = "https://oapi.dingtalk.com/topapi/message/corpconversation/asyncsend_v2?access_token=";


}
