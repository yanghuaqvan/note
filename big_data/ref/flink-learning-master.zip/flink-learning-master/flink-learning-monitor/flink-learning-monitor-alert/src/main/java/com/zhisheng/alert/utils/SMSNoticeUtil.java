package com.zhisheng.alert.utils;


/**
 * 短信通知工具类
 */
public class SMSNoticeUtil {
}
