package com.zhisheng.alert.utils;


/**
 * 电话通知工具类
 */
public class PhoneNoticeUtil {
}
