## Flink 监控告警

### Flink JobManager


### Flink TaskManager

### Flink Jobs


## 通知方式

### 钉钉

+ text 格式消息
+ markdown 格式消息
+ link 格式消息
+ 同一个钉钉地址发送多条消息
+ 同一条消息发送多个群
+ 钉钉工作通知

工具类 [DingDingGroupMsgUtil.java](./src/main/java/com/zhisheng/alert/utils/DingDingGroupMsgUtil.java)

如何使用，请参考 [DingDingMsgTest.java](./src/test/java/DingDingMsgTest.java)

### 邮件


### 短信


### 电话