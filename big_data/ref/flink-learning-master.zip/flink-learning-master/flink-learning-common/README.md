### Flink-learning-common

这个模块存放通用的代码（实体类、工具类、常量类）