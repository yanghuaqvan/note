package com.zhisheng.common.constant;

/**
 * Desc:
 * Created by zhisheng on 2019/10/15 上午12:20
 * blog：http://www.54tianzhisheng.cn/
 * 微信公众号：zhisheng
 */
public class MachineConstant {
    public static final String CLUSTER_NAME = "cluster_name";
    public static final String HOST_IP = "host_ip";
    public static final String LOAD5 = "load5";
    public static final String USED_PERCENT = "usedPercent";
    public static final String CPU = "cpu";
    public static final String MEM = "mem";
    public static final String LOAD = "load";
    public static final String SWAP = "swap";

}
