package com.zhisheng.core.factory;

/**
 * Desc:
 * blog：http://www.54tianzhisheng.cn/
 * 微信公众号：zhisheng
 */
public class DeserializerFactory {
}
