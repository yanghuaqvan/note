## Flink connector Hive

Flink 1.9 版本开始支持 Hive Connector

https://ci.apache.org/projects/flink/flink-docs-release-1.9/dev/table/hive/