### Flink connectors Kudu

https://github.com/apache/bahir-flink/blob/master/flink-connector-kudu/README.md
