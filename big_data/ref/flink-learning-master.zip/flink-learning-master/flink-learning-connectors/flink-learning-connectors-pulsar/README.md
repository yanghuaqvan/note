### Flink-learning-connectors-pulsar

**Pulsar 介绍**：

[Pulsar 官网](https://pulsar.apache.org/)

[Introduction to the Apache Pulsar pub-sub messaging platform](https://streaml.io/blog/intro-to-pulsar)


**Pulsar & Flink**：

[pulsar-flink](https://github.com/streamnative/pulsar-flink)

[When Flink & Pulsar Come Together](https://flink.apache.org/2019/05/03/pulsar-flink.html)

[Flink Pulsar Connector](https://cwiki.apache.org/confluence/display/FLINK/FLIP-72%3A+Introduce+Pulsar+Connector)


**Pulsar VS Kafka**:

[雅虎日本如何用 Pulsar 构建日均千亿的消息平台？](https://www.infoq.cn/article/pcfrbUj7THZH_qs9E6ZV)