package com.zhisheng.connectors.pulsar;

/**
 * Desc: Pulsar Source
 * Created by zhisheng on 2019-11-30 10:15
 * blog：http://www.54tianzhisheng.cn/
 * 微信公众号：zhisheng
 */
public class PulsarSourceMain {
    public static void main(String[] args) {

    }
}
