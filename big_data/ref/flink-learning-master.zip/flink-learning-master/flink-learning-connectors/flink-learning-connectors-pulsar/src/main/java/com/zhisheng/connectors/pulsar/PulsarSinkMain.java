package com.zhisheng.connectors.pulsar;

/**
 * Desc: Pulsar sink
 * Created by zhisheng on 2019-11-30 10:16
 * blog：http://www.54tianzhisheng.cn/
 * 微信公众号：zhisheng
 */
public class PulsarSinkMain {
    public static void main(String[] args) {

    }
}
