package com.zhisheng.connectors.jdbc;

/**
 * Desc: sink to mysql
 * Created by zhisheng on 2019-10-28 18:49
 * blog：http://www.54tianzhisheng.cn/
 * 微信公众号：zhisheng
 */
public class Main {
    public static void main(String[] args) {




    }
}
