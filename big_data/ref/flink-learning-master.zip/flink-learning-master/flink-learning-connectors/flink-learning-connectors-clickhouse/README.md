### Flink connector Clickhouse

https://github.com/ivi-ru/flink-clickhouse-sink