### Flink-learning-connectors-rocketmq

Flink 消费 RocketMQ 数据，转换后再将转换后到数据发送到 RocketMQ，demo 类可以参考 RocketMQFlinkExample 类。