package com.zhisheng.connectors.es5;

/**
 * Desc: sink data to es5
 * Created by zhisheng on 2019/10/22 下午5:10
 * blog：http://www.54tianzhisheng.cn/
 * 微信公众号：zhisheng
 */
public class Sink2ES5Main {
}
