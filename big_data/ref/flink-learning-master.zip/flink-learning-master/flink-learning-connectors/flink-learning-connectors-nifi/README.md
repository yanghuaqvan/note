### Flink-learning-connectors-nifi

**NiFi 介绍**：An easy to use, powerful, and reliable system to process and distribute data.

![](http://zhisheng-blog.oss-cn-hangzhou.aliyuncs.com/img/2019-11-24-030837.jpg)


[Apache NiFi的一些学习资源](https://zhuanlan.zhihu.com/p/58168227)