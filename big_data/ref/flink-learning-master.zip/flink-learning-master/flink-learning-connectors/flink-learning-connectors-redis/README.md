### Flink connector Redis

利用自带的 Redis Connector 从 Kafka 中读取数据，然后写入到 Redis。

Redis 分三种情况：

+ 单机 Redis

+ Redis 集群

+ Redis Sentinels